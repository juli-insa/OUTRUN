/**
 * @file main.js
 * Entry point.
 * 1. Boots the Phaser layer (audio, particles, tweens, gamepad).
 * 2. Loads game assets.
 * 3. Initialises the pseudo-3D engine and SceneManager.
 */

function loop(time, sceneManager) {
    requestAnimationFrame((t) => loop(t, sceneManager));

    const deltaMs      = time - timeObject.elapsed;
    timeObject.delta   = deltaMs;
    timeObject.elapsed = time;

    sceneManager.update(deltaMs);
}

function init(time) {
    const render = new Render(CANVAS.getContext("2d"));
    const camera = new Camera();
    const player = new Player();
    const road   = new Road();
    const state  = new GameState();

    player.sprite.image       = resource.get("car");
    player.sprite.frameWidth  = CONFIG.PLAYER.FRAME_WIDTH;
    player.sprite.frameHeight = CONFIG.PLAYER.FRAME_HEIGHT;
    player.sprite.totalFrames = CONFIG.PLAYER.TOTAL_FRAMES;
    player.sprite.frameSpeed  = CONFIG.PLAYER.FRAME_SPEED;

    // spriteCardobla — spritesheet VERTICAL (30×70px)
    // row 0 = dobla derecha, row 1 = dobla izquierda
    player.spriteCardobla.image       = resource.get("cardobla");
    player.spriteCardobla.frameWidth  = 30;   // ancho de un frame (= ancho total)
    player.spriteCardobla.frameHeight = 35;   // alto de UN frame (mitad del spritesheet)
    player.spriteCardobla.totalFrames = 2;
    player.spriteCardobla.frameSpeed  = 0;    // sin animación automática — lo controlamos manual

    road.create();

    const sky = new Sky();
    sky.init(resource.get("nuve"));

    const sceneManager = new SceneManager();
    sceneManager.init(render, camera, player, road, state, sky);

    loop(time, sceneManager);
}

// ── Boot sequence ─────────────────────────────────────────────────────────────
// 1. Start Phaser (async — loads its canvas and audio context)
phaserLayer.init();

// 2. Load game image assets, then start the engine
resource
    .add("tree1",       "./assets/foliagePack_005.png")
    .add("car",         "./assets/car.png")
    .add("cardobla",    "./assets/cardobla.png")
    .add("finish-line", "./assets/finish.png")
    .add("tree2",       "./assets/foliagePack_013.png")
    .add("nuve",        "./assets/nuve.png")
    .load(() => requestAnimationFrame((t) => init(t)));
