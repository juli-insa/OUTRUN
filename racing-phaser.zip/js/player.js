/**
 * @file player.js
 * The player-controlled car.
 *
 * Spritesheet cardobla — VERTICAL (30×70px):
 *   row 0 (y=0)  → dobla a la DERECHA
 *   row 1 (y=35) → dobla a la IZQUIERDA
 *
 * Sin flip, sin transformaciones — simplemente elegimos el frame correcto.
 */

class Player {
    x = 0;
    y = 0;
    z = 0;

    sprite         = new AnimatedSprite();
    spriteCardobla = new AnimatedSprite();

    isCardobla   = false;
    isMovingLeft = false;

    /** Set each frame by GameplayScene from the active road segment. */
    currentCurve = 0;

    /** How strongly curves push the car off-lane. */
    static DRIFT_FACTOR = 0.00015;

    get currentSprite() {
        return this.isCardobla ? this.spriteCardobla : this.sprite;
    }

    get width()  { return this.currentSprite.width;  }
    get height() { return this.currentSprite.height; }

    /** @param {number} speed  0-255 */
    update(speed = 0) {
        const gp    = phaserLayer.gamepad;
        const axisX = gp.axes().lx;

        const left  = keyboard.isKeyDown("arrowleft")
                   || gp.isDown(GamepadButtons.LEFT)
                   || axisX < -0.3;

        const right = keyboard.isKeyDown("arrowright")
                   || gp.isDown(GamepadButtons.RIGHT)
                   || axisX > 0.3;

        this.isCardobla   = left || right;
        this.isMovingLeft = left;

        const lateralSpeed = Math.abs(axisX) > 0.3
            ? CONFIG.PLAYER.LATERAL_SPEED * Math.abs(axisX)
            : CONFIG.PLAYER.LATERAL_SPEED;

        if (left)       this.x -= lateralSpeed;
        else if (right) this.x += lateralSpeed;

        // Curve drift
        this.x += this.currentCurve * speed * Player.DRIFT_FACTOR;

        // ── Elegir frame según dirección (sin flip) ────────────
        if (this.isCardobla) {
            this.spriteCardobla.frameIndex = this.isMovingLeft ? 1 : 0;
        }
    }

    /**
     * @param {Render} render
     * @param {Camera} camera
     * @param {number} roadWidth
     */
    render(render, camera, roadWidth) {
        const mid   = camera.screen.midpoint;
        const scale = 1 / camera.h;
        const destX = mid.x;
        const destY = camera.screen.height;

        // Sin transformaciones — el frame correcto ya fue elegido en update()
        render.drawSprite(this.currentSprite, camera, this, null, roadWidth, scale, destX, destY, 0);
    }
}
